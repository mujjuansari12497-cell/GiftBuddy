package com.giftbuddy.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Gift(val name:String,val price:Int,val relation:String,val occasion:String,val emoji:String)

class MainActivity:AppCompatActivity(){
 private val gifts=listOf(
  Gift("Personalized Photo Frame",499,"Friend","Birthday","🖼️"),
  Gift("Perfume Gift Set",999,"Wife","Birthday","🌸"),
  Gift("Smart Watch",2499,"Brother","Birthday","⌚"),
  Gift("Personalized Mug",399,"Friend","Thank You","☕"),
  Gift("Wallet",799,"Husband","Anniversary","👛"),
  Gift("Chocolate Gift Box",699,"Wife","Valentine","🍫"),
  Gift("Bluetooth Speaker",1499,"Brother","Birthday","🔊"),
  Gift("Plant Gift",499,"Parents","Housewarming","🪴"),
  Gift("Premium Pen",1299,"Father","Birthday","🖊️"),
  Gift("Handmade Photo Album",899,"Parents","Anniversary","📔")
 )
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}
 private fun home(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,16)}
  root.addView(TextView(this).apply{text="🎁 GiftBuddy";textSize=30f;setTextColor(0xFF5B21B6.toInt())})
  root.addView(TextView(this).apply{text="Kisko gift dena hai?";textSize=17f;setPadding(0,6,0,12)})
  val search=EditText(this).apply{hint="🔍 Gift search";singleLine=true};root.addView(search)
  val rel=Spinner(this);rel.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Any Relation","Wife","Husband","Friend","Brother","Parents","Father"));root.addView(rel)
  val occ=Spinner(this);occ.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Any Occasion","Birthday","Anniversary","Valentine","Housewarming","Thank You"));root.addView(occ)
  val btn=Button(this).apply{text="🎁 Gift Ideas Dikhao"};root.addView(btn)
  val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  btn.setOnClickListener{
   list.removeAllViews();val q=search.text.toString().trim().lowercase();val r=rel.selectedItem.toString();val o=occ.selectedItem.toString()
   gifts.filter{(q.isEmpty()||it.name.lowercase().contains(q))&&(r=="Any Relation"||it.relation==r)&&(o=="Any Occasion"||it.occasion==o)}.forEach{g->
    val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,14,16,14);setBackgroundColor(0xFFF5F3FF.toInt())}
    box.addView(TextView(this).apply{text="${g.emoji} ${g.name}";textSize=19f})
    box.addView(TextView(this).apply{text="₹${g.price} • ${g.relation} • ${g.occasion}";textSize=15f})
    box.addView(Button(this).apply{text="🛒 Search / Buy";setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(g.name+" buy online India"))))}})
    val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,12);list.addView(box,lp)
   }
  }
  setContentView(root);btn.performClick()
 }
}
